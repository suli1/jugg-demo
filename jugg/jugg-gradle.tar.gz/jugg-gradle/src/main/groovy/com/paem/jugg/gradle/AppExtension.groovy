package com.paem.jugg.gradle;

/**
 * Created by suli690 on 2017/9/14.
 */

public class AppExtension {

  int packageId = 0x7f
}

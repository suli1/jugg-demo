package com.paem.jugg.gradle

import com.android.build.gradle.BaseExtension
import com.paem.jugg.gradle.utils.DependenciesUtils
import org.gradle.api.Project
import org.gradle.api.Task

/**
 * Created by suli690 on 2017/9/15.*/

public class LibraryPlugin extends BasePlugin {

  protected Set<Project> mDependentLibProjects
  protected Set<Project> mTransitiveDependentLibProjects
  protected Set<Project> mProvidedProjects
  protected Set<Project> mCompiledProjects
  protected Set<Map> mUserLibAars
  protected Set<File> mLibraryJars
  protected File mMinifyJar

  Task jarTask;

  protected BaseExtension getAndroid() {
    return project.android
  }

  @Override
  protected Class<?> getExtensionClass() {
    return LibraryExtension.class
  }

  @Override
  protected LibraryExtension getSmall() {
    return project.small
  }

  @Override
  protected void createTask() {
    super.createTask()
  }

  @Override
  protected void afterEvaluate() {
    super.afterEvaluate()
    android.libraryVariants.all { variant ->
      if (jarTask == null) {
        jarTask = project.jarReleaseClasses
        Task buildLibTask = project.task('buildLib', dependsOn: 'assembleRelease')
        buildLibTask.group = AppConstant.TASK_GROUP
        buildLibTask.doLast {
          buildLib()
        }
      }
    }
  }

  private void buildLib() {
    def libName = project.name
    //    Task jarTask = project.jarReleaseClasses

    //    // Copy jars  build-small/intermediates/small-pre-jar/base/
    //    def preJarDir = small.preBaseJarDir
    //    if (!preJarDir.exists()) preJarDir.mkdirs()
    //    //  - copy package.R jar
    //    if (jarTask != null) {
    //      def rJar = jarTask.archivePath
    //      project.copy {
    //        from rJar
    //        into preJarDir
    //        rename { "$libName-r.jar" }
    //      }
    //      println "copy jar from ${rJar} to ${preJarDir}/${libName}-r.jar"
    //    }

    //  - copy dependencies jars
    ext.buildCaches.each { k, v ->
      // explodedDir: [key:value]
      // [com.android.support/appcompat-v7/25.2.0:\Users\admin\.android\build-cache\hash\output]
      File jarDir = new File(v, 'jars')
      File jarFile = new File(jarDir, 'classes.jar')
      if (!jarFile.exists()) return
      def key = k.split("/")
      def group = key[0]
      def artifact = key[1]
      def version = key[2]
      File destFile = new File(preJarDir,
          "${group}-${artifact}-${version}.jar")
      if (destFile.exists()) return

      project.copy {
        from jarFile
        into preJarDir
        rename { destFile.name }
      }
      println "copy buildCaches jar from ${jarFile} to ${preJarDir}/${destFile.name}"

      // Check if exists `jars/libs/*.jar' and copy
      File libDir = new File(jarDir, 'libs')
      libDir.listFiles().each { jar ->
        if (!jar.name.endsWith('.jar')) return

        destFile = new File(preJarDir, "${group}-${artifact}-${jar.name}")
        if (destFile.exists()) return

        project.copy {
          from jar
          into preJarDir
          rename { destFile.name }
        }
        println "copy libDir jar from ${jar} to ${preJarDir}/${destFile.name}"
      }
    }

    //    // Copy *.ap_
    //    def aapt = ext.aapt
    //    def preApDir = small.preApDir
    //    if (!preApDir.exists()) preApDir.mkdir()
    //    def apFile = aapt.packageOutputFile
    //    def preApName = "$libName-resources.ap_"
    //    project.copy {
    //      from apFile
    //      into preApDir
    //      rename { preApName }
    //    }
    //    println "copy *.ap_ from ${apFile} to ${preApDir}/${preApName}"

    //    // Copy R.txt
    //    def preIdsDir = small.preIdsDir
    //    if (!preIdsDir.exists()) preIdsDir.mkdir()
    //    def srcIdsFile = new File(aapt.textSymbolOutputDir, 'R.txt')
    //    if (srcIdsFile.exists()) {
    //      def idsFileName = "${libName}-R.txt"
    //      def keysFileName = 'R.keys.txt'
    //      def dstIdsFile = new File(preIdsDir, idsFileName)
    //      def keysFile = new File(preIdsDir, keysFileName)
    //      def addedKeys = []
    //      if (keysFile.exists()) {
    //        keysFile.eachLine { s ->
    //          addedKeys.add(SymbolParser.getResourceDeclare(s))
    //        }
    //      }
    //      def idsPw = new PrintWriter(dstIdsFile.newWriter(true)) // true=append mode
    //      def keysPw = new PrintWriter(keysFile.newWriter(true))
    //      srcIdsFile.eachLine { s ->
    //        def key = SymbolParser.getResourceDeclare(s)
    //        if (addedKeys.contains(key)) return
    //        idsPw.println(s)
    //        keysPw.println(key)
    //      }
    //      idsPw.flush()
    //      idsPw.close()
    //      keysPw.flush()
    //      keysPw.close()
    //    }
    //    println "Copy R.txt from srcIds:${srcIdsFile.getAbsolutePath()}"

    // Backup dependencies
    if (!small.preLinkAarDir.exists()) small.preLinkAarDir.mkdirs()
    if (!small.preLinkJarDir.exists()) small.preLinkJarDir.mkdirs()
    def linkFileName = "$libName-D.txt"
    File aarLinkFile = new File(small.preLinkAarDir, linkFileName)
    File jarLinkFile = new File(small.preLinkJarDir, linkFileName)

    def allDependencies = DependenciesUtils.getAllDependencies(lib, 'compile')
    if (allDependencies.size() > 0) {
      def aarKeys = []
      if (!aarLinkFile.exists()) {
        aarLinkFile.createNewFile()
      } else {
        aarLinkFile.eachLine {
          aarKeys.add(it)
        }
      }

      def jarKeys = []
      if (!jarLinkFile.exists()) {
        jarLinkFile.createNewFile()
      } else {
        jarLinkFile.eachLine {
          jarKeys.add(it)
        }
      }

      def aarPw = new PrintWriter(aarLinkFile.newWriter(true))
      def jarPw = new PrintWriter(jarLinkFile.newWriter(true))

      // Cause the later aar(as fresco) may dependent by 'com.android.support:support-compat'
      // which would duplicate with the builtin 'appcompat' and 'support-v4' library in host.
      // Hereby we also mark 'support-compat' has compiled in host.
      allDependencies.each { d ->
        def isAar = true
        d.moduleArtifacts.each { art ->
          // Copy deep level jar dependencies
          File src = art.file
          if (art.type == 'jar') {
            isAar = false
            project.copy {
              from src
              into preJarDir
              rename { "${d.moduleGroup}-${src.name}" }
            }
          }
        }
        if (isAar) {
          if (!aarKeys.contains(d.name)) {
            aarPw.println d.name
          }
        } else {
          if (!jarKeys.contains(d.name)) {
            jarPw.println d.name
          }
        }
      }
      jarPw.flush()
      jarPw.close()
      aarPw.flush()
      aarPw.close()
    }
  }
}

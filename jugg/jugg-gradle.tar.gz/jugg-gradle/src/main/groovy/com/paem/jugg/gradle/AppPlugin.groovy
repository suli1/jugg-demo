package com.paem.jugg.gradle

import com.android.build.gradle.BaseExtension
import com.android.build.gradle.api.BaseVariant
import com.android.build.gradle.internal.pipeline.TransformTask
import com.android.build.gradle.tasks.ProcessAndroidResources
import org.gradle.api.Project
import org.gradle.api.Task
import org.gradle.api.artifacts.DependencySet
import org.gradle.api.internal.artifacts.dependencies.DefaultProjectDependency
import org.gradle.api.tasks.compile.JavaCompile

/**
 * Created by suli690 on 2017/9/14.*/

public class AppPlugin extends BasePlugin {

  protected Set<Project> mDependentLibProjects
  protected Set<Project> mTransitiveDependentLibProjects
  protected Set<Project> mProvidedProjects
  protected Set<Project> mCompiledProjects
  protected Set<Map> mUserLibAars
  protected Set<File> mLibraryJars
  protected File mMinifyJar

  protected BaseExtension getAndroid() {
    return project.android
  }

  @Override
  protected Class<?> getExtensionClass() {
    return AppExtension.class
  }

  @Override
  protected AppExtension getSmall() {
    return project.small
  }

  @Override
  protected void beforeEvaluate() {
    super.beforeEvaluate()
  }

  @Override
  protected void afterEvaluate() {
    super.afterEvaluate()
    // Initialize a resource package id for current bundle
    //    initPackageId() // AAPT id 分段

    // Get all dependencies with gradle script `compile project(':lib.*')'
    DependencySet compilesDependencies = project.configurations.compile.dependencies
    Set<DefaultProjectDependency> allLibs = compilesDependencies.withType(
        DefaultProjectDependency.class)
    Set<DefaultProjectDependency> smallLibs = []
    mUserLibAars = []
    mDependentLibProjects = []
    mProvidedProjects = []
    mCompiledProjects = []
    allLibs.each {
      if (rootSmall.isLibProject(it.dependencyProject)) {
        smallLibs.add(it)
        mProvidedProjects.add(it.dependencyProject)
        mDependentLibProjects.add(it.dependencyProject)
        println "Add provided dependency project: ${it.name}"
      } else {
        mCompiledProjects.add(it.dependencyProject)
        collectAarsOfLibrary(it.dependencyProject, mUserLibAars)
        println "Add compile dependency project: ${it.name}"
      }
    }
    collectAarsOfLibrary(project, mUserLibAars)

    if (rootSmall.isBuildingLibs()) {
      // While building libs, `lib.*' modules are changing to be an application
      // module and cannot be depended by any other modules. To avoid warnings,
      // remove the `compile project(':lib.*')' dependencies temporary.
      compilesDependencies.removeAll(smallLibs)
    }

    // hookPreBuild
    def preBuild = project.tasks['preBuild']
    preBuild.doFirst {
      hookPreBuild()
    }

    // Application config
    if (android.hasProperty("applicationVariants")) {
      android.applicationVariants.all { variant -> configureVariant(variant)
      }
    }
  }

  @Override
  protected void createTask() {
    super.createTask()
    Task buildBundle = project.task('buildBundle', dependsOn: 'assembleRelease')
    buildBundle.group = AppConstant.TASK_GROUP
  }

  private void hookPreBuild() {
    // Ensure generating text symbols - R.txt
    // --------------------------------------
    def symbolsPath = small.aapt.textSymbolOutputDir.path
    android.aaptOptions.additionalParameters '--output-text-symbols', symbolsPath

    // Resolve dependent AARs
    // ----------------------
    def smallLibAars = new HashSet()
    // the aars compiled in host or lib.*

    // Collect transitive dependent `lib.*' projects
    mTransitiveDependentLibProjects = new HashSet<>()
    mTransitiveDependentLibProjects.addAll(mProvidedProjects)
    mProvidedProjects.each {
      collectLibProjects(it, mTransitiveDependentLibProjects)
    }

    // Collect aar(s) in lib.*
    mTransitiveDependentLibProjects.each { lib -> // lib.* dependencies
      collectAarsOfProject(lib, true, smallLibAars)
    }

    // Collect aar(s) in host
    collectAarsOfProject(rootSmall.hostProject, false, smallLibAars)

    small.splitAars = smallLibAars
    small.retainedAars = mUserLibAars
  }

  private void configureVariant(BaseVariant variant) {
    // plugin output
    //    def outputFile = getOutputFile(variant)
    //    BundleExtension ext = small
    //    ext.outputFile = outputFile
    //    variant.outputs.each { out ->
    //      out.outputFile = outputFile
    //    }
    // Fill extensions
    def variantName = variant.name.capitalize()
    File mergerDir = variant.mergeResources.incrementalFolder

    small.with {
      javac = variant.javaCompile
      processManifest = project.tasks["process${variantName}Manifest"]

      packageName = variant.applicationId
      packagePath = packageName.replaceAll('\\.', '/')
      classesDir = javac.destinationDir
      bkClassesDir = new File(classesDir.parentFile, "${classesDir.name}~")

      aapt = (ProcessAndroidResources) project.tasks["process${variantName}Resources"]
      apFile = aapt.packageOutputFile

      File symbolDir = aapt.textSymbolOutputDir
      File sourceDir = aapt.sourceOutputDir

      symbolFile = new File(symbolDir, 'R.txt')
      rJavaFile = new File(sourceDir, "${packagePath}/R.java")

      splitRJavaFile = new File(sourceDir.parentFile, "small/${packagePath}/R.java")

      mergerXml = new File(mergerDir, 'merger.xml')
    }

    hookVariantTask(variant)
  }

  private void hookVariantTask(BaseVariant variant) {
    //    hookMergeAssets(variant.mergeAssets)
    //    hookProcessManifest(small.processManifest)
    //    hookAapt(small.aapt)

    hookJavac(small.javac, variant.buildType.minifyEnabled)

    hookKotlinCompile()

    def transformTasks = project.tasks.withType(TransformTask.class)
    def mergeJniLibsTask = transformTasks.find {
      it.transform.name == 'mergeJniLibs' && it.variantName == variant.name
    }
    hookMergeJniLibs(mergeJniLibsTask)

    def mergeJavaResTask = transformTasks.find {
      it.transform.name == 'mergeJavaRes' && it.variantName == variant.name
    }
    hookMergeJavaRes(mergeJavaResTask)

    // Hook clean task to unset package id
    project.clean.doLast {
      sPackageIds.remove(project.name)
    }
  }

  /**
   * Hook javac task to split libraries' R.class*/
  private def hookJavac(Task javac, boolean minifyEnabled) {
    addClasspath(javac)
    javac.doLast { JavaCompile it ->
      if (minifyEnabled) return // process later in proguard task
      if (!small.splitRJavaFile.exists()) return

      File classesDir = it.destinationDir
      File dstDir = new File(classesDir, small.packagePath)

      // Delete the original generated R$xx.class
      dstDir.listFiles().each { f ->
        if (f.name.startsWith('R$')) {
          f.delete()
        }
      }
      // Re-compile the split R.java to R.class
      project.ant.javac(srcdir: small.splitRJavaFile.parentFile,
          source: it.sourceCompatibility,
          target: it.targetCompatibility,
          destdir: classesDir)

      Log.success "[${project.name}] split R.class..."
    }
  }

  private def hookKotlinCompile() {
    project.tasks.all {
      if (it.name.startsWith('compile') && it.name.endsWith('Kotlin') &&
          it.hasProperty('classpath')) {
        addClasspath(it)
      }
    }
  }

  /**
   * Hook merge-jniLibs task to ignores the lib.* native libraries
   * TODO: filter the native libraries while exploding aar*/
  def hookMergeJniLibs(TransformTask t) {
    stripAarFiles(t, { splitPaths ->
      t.streamInputs.each {
        if (shouldStripInput(it)) {
          splitPaths.add(it)
        }
      }
    })
  }

  /**
   * Hook merge-javaRes task to ignores the lib.* jar assets*/
  def hookMergeJavaRes(TransformTask t) {
    stripAarFiles(t, { splitPaths ->
      t.streamInputs.each {
        if (shouldStripInput(it)) {
          splitPaths.add(it)
        }
      }
    })
  }

  protected def addClasspath(Task javac) {
    javac.doFirst {
      // Dynamically provided jars
      javac.classpath += project.files(getLibraryJars().findAll { it.exists() })
    }
  }

  protected def collectAarsOfProject(Project project, boolean isLib, HashSet outAars) {
    String dependenciesFileName = "$project.name-D.txt"

    // Pure aars
    File file = new File(rootSmall.preLinkAarDir, dependenciesFileName)
    collectAars(file, project, outAars)

    // Jar-only aars
    file = new File(rootSmall.preLinkJarDir, dependenciesFileName)
    collectAars(file, project, outAars)

    if (isLib) {
      collectAarsOfLibrary(project, outAars)
    }
  }

  protected static def collectAarsOfLibrary(Project lib, HashSet outAars) {
    // lib.* self
    outAars.add(group: lib.group, name: lib.name, version: lib.version)
    // lib.* self for android plugin 2.3.0+
    File dir = lib.projectDir
    outAars.add(group: dir.parentFile.name, name: dir.name, version: lib.version)
  }

  /**
   * A hack way to strip aar files:
   *  - Strip the task inputs before the task execute
   *  - Restore the inputs after the task executed
   * by what the task doesn't know what happen, and will be considered as 'UP-TO-DATE'
   * at next time it be called. This means a less I/O.
   * @param t the task who will merge aar files
   * @param closure the function to gather all the paths to be stripped
   */
  private static void stripAarFiles(Task t, Closure closure) {
    t.doFirst {
      List<File> stripPaths = []
      closure(stripPaths)

      Set<Map> strips = []
      stripPaths.each {
        def backup = new File(it.parentFile, "$it.name~")
        strips.add(org: it, backup: backup)
        it.renameTo(backup)
        println "strip aar files backup:${backup.absolutePath}"
      }
      it.extensions.add('strips', strips)
    }
    t.doLast {
      Set<Map> strips = (Set<Map>) it.extensions.getByName('strips')
      strips.each {
        it.backup.renameTo(it.org)
        println "strip aar files rename to org:${it.org}"
      }
    }
  }
}

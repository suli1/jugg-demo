package com.paem.jugg.gradle.utils

import org.gradle.api.Project
import org.gradle.api.artifacts.Configuration
import org.gradle.api.artifacts.ResolvedConfiguration
import org.gradle.api.artifacts.ResolvedDependency
import org.gradle.api.artifacts.UnknownConfigurationException

/** Class to resolve project dependencies */
public final class DependenciesUtils {

  public static Set<ResolvedDependency> getAllDependencies(Project project, String config) {
    Configuration configuration
    try {
      configuration = project.configurations[config]
    } catch (UnknownConfigurationException ignored) {
      return null
    }

    return getAllDependencies(configuration)
  }

  public static Set<ResolvedDependency> getAllDependencies(Configuration configuration) {
    ResolvedConfiguration resolvedConfiguration = configuration.resolvedConfiguration
    def firstLevelDependencies = resolvedConfiguration.firstLevelModuleDependencies
    Set<ResolvedDependency> allDependencies = new HashSet<>()
    firstLevelDependencies.each {
      collectDependencies(it, allDependencies)
    }
    return allDependencies
  }

  private static void collectDependencies(ResolvedDependency node, Set<ResolvedDependency> out) {
    if (out.find { addedNode -> addedNode.name == node.name } == null) {
      out.add(node)
    }
    // Recursively
    node.children.each { newNode -> collectDependencies(newNode, out)
    }
  }
}
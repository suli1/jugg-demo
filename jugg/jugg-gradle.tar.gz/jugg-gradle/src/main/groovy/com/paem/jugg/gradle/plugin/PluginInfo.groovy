package com.paem.jugg.gradle.plugin;

/**
 * Created by suli690 on 2017/8/16.
 */

public class PluginInfo {
  def name; // 插件名
  def minVersion;
  def version;
  def mainClass;
  def otherInfo;
  def flag;
}

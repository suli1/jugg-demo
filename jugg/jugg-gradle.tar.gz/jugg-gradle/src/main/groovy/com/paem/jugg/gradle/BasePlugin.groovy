package com.paem.jugg.gradle

import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * Created by suli690 on 2017/9/14.*/

public abstract class BasePlugin implements Plugin<Project> {
  protected Project project

  @Override
  void apply(Project project) {
    this.project = project

    createExtension()
    configureProject()
    createTask()
  }

  protected void createExtension() {
    if (getExtensionClass() != null) {
      project.extensions.create('small', getExtensionClass(), project)
    }
  }

  private void configureProject() {
    project.beforeEvaluate {
      beforeEvaluate()
    }

    project.afterEvaluate {
      afterEvaluate()
    }
  }

  protected void beforeEvaluate() {}

  protected void afterEvaluate() {}

  protected void createTask() {}

  protected abstract Class<?> getExtensionClass()

  protected abstract def getSmall()
}

package com.paem.jugg.gradle;

/**
 * Created by suli690 on 2017/9/15.*/

class RootPlugin extends BasePlugin {
  @Override
  protected Class<?> getExtensionClass() {
    return null
  }

  @Override
  protected getSmall() {
    return null
  }
}

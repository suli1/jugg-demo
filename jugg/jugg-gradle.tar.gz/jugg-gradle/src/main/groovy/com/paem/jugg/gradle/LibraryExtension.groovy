package com.paem.jugg.gradle

import org.gradle.api.Project

/**
 * Created by suli690 on 2017/9/15.*/

class LibraryExtension {
  private static final String FD_BUILD_SMALL = 'build-small'

  private static final String FD_PLUGIN = 'plugin'
  private static final String FD_INTERMEDIATES = "intermediates"
  private static final String FD_PRE_JAR = 'small-pre-jar'
  private static final String FD_PRE_LINK = 'small-pre-link'
  private static final String FD_BASE = 'base'
  private static final String FD_LIBS = 'libs'
  private static final String FD_JAR = 'jar'
  private static final String FD_AAR = 'aar'

  private File preBuildDir

  /** Directory to output bundles (*.apk) */
  private File outputBundleDir

  /** Directory of pre-build host and android support jars */
  private File preBaseJarDir

  /** Directory of pre-build libs jars */
  private File preLibsJarDir

  /** Directory of prepared dependencies */
  private File preLinkAarDir
  private File preLinkJarDir

  LibraryExtension(Project project) {
    preBuildDir = new File(project.projectDir, FD_BUILD_SMALL)
    outputBundleDir = new File(preBuildDir, FD_PLUGIN)
    def interDir = new File(preBuildDir, FD_INTERMEDIATES)
    def jarDir = new File(interDir, FD_PRE_JAR)
    preBaseJarDir = new File(jarDir, FD_BASE)
    preLibsJarDir = new File(jarDir, FD_LIBS)
    def preLinkDir = new File(interDir, FD_PRE_LINK)
    preLinkJarDir = new File(preLinkDir, FD_JAR)
    preLinkAarDir = new File(preLinkDir, FD_AAR)
  }

  File getPreBuildDir() {
    return preBuildDir
  }

  File getOutputBundleDir() {
    return outputBundleDir
  }

  File getPreBaseJarDir() {
    return preBaseJarDir
  }

  File getPreLibsJarDir() {
    return preLibsJarDir
  }

  File getPreLinkAarDir() {
    return preLinkAarDir
  }

  File getPreLinkJarDir() {
    return preLinkJarDir
  }
}
